import base64,os,json
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def b64(p): return 'data:image/jpeg;base64,'+base64.b64encode(open(p,'rb').read()).decode()
IMGS=[b64(f'../img/lvl{i}.jpg') for i in range(1,6)]
Q=[
 ("Quan va ser l'última vegada que vas usar una IA per a alguna cosa de classe?",1,
  ["Mai, o només per curiositat fora de l'aula","Fa setmanes o mesos, per a provar","Cada setmana, per a alguna tasca concreta","Pràcticament cada dia: ja forma part de com treballe"]),
 ("Quan li demanes alguna cosa a la IA, què li escrius?",1,
  ["Una frase curta, com si fora Google","Li explique una miqueta el context (curs, tema)","Li done rol, context, format i algun exemple","Tinc plantilles de prompts guardades que reutilitze"]),
 ("I amb la resposta que et dona, què fas?",5,
  ["La copie i la use tal qual","La llig per damunt i corregisc el que grinyola","La contraste amb el currículum o amb una font fiable","La itere fins que és realment meua i documente d'on ix"]),
 ("Necessites una activitat per a la classe de demà. Amb IA…",2,
  ["No sabria per on començar","He provat alguna vegada, amb resultats regulars","La genere i l'ajuste al meu grup sense problema","La genere en tres versions (reforç, base, ampliació) en minuts"]),
 ("Adaptar un material a un alumne concret (idioma, DUA, reforç, TEA…)",2,
  ["Ho faig a mà, si tinc temps","Sé que la IA pot ajudar, però no ho he provat","Ho faig amb IA de tant en tant","Tinc un flux fix: original → adaptació → revisió"]),
 ("Programacions, situacions d'aprenentatge, unitats didàctiques…",3,
  ["Mai les he tocat amb IA","Ho he provat, però no em fie del resultat","Les redacte amb IA amb el currículum oficial al costat","Les genere, revise criteris i sabers, i les versione per grup"]),
 ("Rúbriques, correcció i retroalimentació a l'alumnat",3,
  ["No use IA per a això","Rúbriques senzilles, poca cosa més","Rúbriques a mida + feedback personalitzat","Analitze evidències del procés i adapte l'avaluació"]),
 ("Saps què és un agent d'IA (un GPT personalitzat, un Gem, un Copilot amb instruccions)?",4,
  ["No en tinc ni idea","N'he sentit parlar","N'he usat algun creat per altres","N'he creat amb instruccions i documents propis"]),
 ("Les tasques repetitives del dia a dia (correus, actes, informes, resums de reunions)",4,
  ["Les faig com sempre, a mà","M'agradaria automatitzar-les però no sé com","Algunes les resolc amb IA","Tinc fluxos muntats que m'estalvien hores cada setmana"]),
 ("Dades de l'alumnat i IA: què fas?",5,
  ["No m'ho havia plantejat","Evite pujar res, per si de cas","Sé exactament què puc pujar, què no i on","Use eines corporatives (Copilot @edu.gva.es) i ho explique als altres"]),
 ("Amb l'alumnat i les famílies, com tractes l'ús de la IA?",5,
  ["No ho hem parlat mai","A vegades ix el tema, sense normes clares","Tinc normes d'ús a la meua aula","Hi ha un acord explícit i l'alumnat sap citar i verificar"]),
 ("Un company et diu: «vull començar amb la IA, per on tire?»",4,
  ["Li diria que jo tampoc ho tinc clar","Li ensenyaria ChatGPT i poc més","Li recomanaria eines segons el que necessite","Li muntaria un mini-taller d'una vesprada"]),
]
LEVELS=[
 dict(n=1,name="Explorador/a",tag="Nivell 1 · Bloc 1",claim="Tens curiositat. I la curiositat és el 80 % del camí.",
  body="Encara no uses la IA de manera habitual o la uses com un buscador amb bones maneres. No passa res: ací és on comença la majoria del professorat. El que et falta no és talent, és un mètode: saber què demanar, com demanar-ho i com comprovar el resultat.",
  start="Bloc 1 · Entendre la IA i prompting educatiu",cursname="Proposta ideal de 9 h (adaptable), amb ritme de fonaments",
  win=["Passar de «prova a veure què ix» a demanar amb rol, context i format","La teua primera activitat adaptada al teu grup en la primera sessió","Saber què pots pujar i què no, des del primer dia"]),
 dict(n=2,name="Creador/a de recursos",tag="Nivell 2 · Bloc 2",claim="Ja saps parlar amb la IA. Ara toca que treballe per a tu.",
  body="Uses la IA per a coses puntuals i te'n surts. Però encara no li traus el rendiment: cada material és un esforç nou i no tens fluxos que et facen guanyar temps de veritat. El salt que et falta és sistematitzar la creació i adaptació de recursos.",
  start="Bloc 2 · Creació d'activitats, recursos i materials adaptats",cursname="Proposta ideal de 9 h (adaptable), amb èmfasi en recursos i adaptació",
  win=["Materials en tres nivells (reforç, base, ampliació) en minuts","Adaptacions DUA i d'idioma amb un flux repetible","Rúbriques i feedback que no et roben el cap de setmana"]),
 dict(n=3,name="Planificador/a amb criteri",tag="Nivell 3 · Bloc 3",claim="Domines l'aula. Ara domina la burocràcia.",
  body="Crees i adaptes materials amb soltesa i revises el que la IA et dona. El teu següent nivell està en la planificació i l'avaluació: programacions amb el currículum al costat, rúbriques a mida i anàlisi d'evidències. I, sobretot, en el salt als agents.",
  start="Bloc 3 · Planificació i avaluació docent amb IA",cursname="Proposta ideal de 9 h (adaptable), amb pes en els blocs 3 i 4",
  win=["Programacions i situacions d'aprenentatge revisades amb criteri","Avaluació formativa amb IA sense perdre el control","El teu primer assistent propi, entrenat amb els teus documents"]),
 dict(n=4,name="Arquitecte/a d'agents",tag="Nivell 4 · Bloc 4",claim="Ja no uses la IA. La dirigeixes.",
  body="Treballes amb agents, tens fluxos que t'estalvien hores i saps què li demanes a cada eina. Estàs al 5 % del professorat. El que et falta és consolidar l'ús responsable i convertir-te en el motor del canvi al teu centre.",
  start="Bloc 4 · Agents d'IA i nous fluxos de treball",cursname="Proposta ideal de 9 h (adaptable) en mode avançat: fluxos, agents i lideratge al claustre",
  win=["Fluxos complets: de la programació a l'informe sense passos manuals","Agents compartits per a departaments i equips","Criteris per a acompanyar la resta del claustre"]),
 dict(n=5,name="Referent d'IA responsable",tag="Nivell 5 · Bloc 5",claim="Eres la persona que el teu centre necessita. Ara falta el teu claustre.",
  body="Uses la IA amb criteri, seguretat i transparència, i ja ajudes als altres. El teu repte no és personal: és col·lectiu. La formació et serveix per a alinear el claustre sencer amb un mateix llenguatge, unes mateixes normes i uns mateixos fluxos.",
  start="Bloc 5 · Ús segur, ètic i responsable (i lideratge del canvi)",cursname="Proposta ideal de 9 h (adaptable) per al claustre, amb tu com a referent intern",
  win=["Un claustre que parla el mateix idioma amb la IA","Acords d'ús amb alumnat i famílies","Continuïtat: què fer després de la formació"]),
]
BLOCS=["Entendre la IA i prompting","Recursos i adaptació","Planificació i avaluació","Agents i fluxos","Ús responsable"]
HOURS=["1h30","2h","2h","2h","1h30"]

html=r'''<!DOCTYPE html>
<html lang="ca"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Quin és el meu nivell en IA? · Test per a docents</title>
<style>
:root{--paper:#FAF5EC;--paper-2:#F3EAD9;--ink:#1F1B16;--ink-2:#4A423A;--mute:#8A7F72;--line:#E5DAC6;--terra:#D9542B;--terra-d:#B8441F;--must:#F2B84B;--sage:#5B8A72;--serif:"Iowan Old Style","Palatino Linotype",Palatino,Georgia,"Times New Roman",serif;--sans:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:var(--paper);color:var(--ink);font-family:var(--sans);line-height:1.55;-webkit-font-smoothing:antialiased}
body::before{content:"";position:fixed;inset:0;background-image:radial-gradient(rgba(31,27,22,.06) 1px,transparent 1px);background-size:22px 22px;pointer-events:none;z-index:0}
.wrap{max-width:900px;margin:0 auto;padding:0 24px;position:relative;z-index:1}
.top{display:flex;align-items:center;justify-content:space-between;height:68px}
.brand{display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--ink)}.brand b{font-family:var(--serif);font-size:16px;font-weight:600}
.back{font-size:13px;font-weight:700;color:var(--ink-2);text-decoration:none;border:1.5px solid var(--line);border-radius:999px;padding:8px 14px}
.kicker{display:flex;align-items:center;gap:10px;font-size:11.5px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--terra)}.kicker::before{content:"";width:28px;height:2px;background:var(--terra)}
h1{font-family:var(--serif);font-weight:600;font-size:clamp(34px,6vw,58px);line-height:1.02;letter-spacing:-.02em;margin:10px 0 14px}
h1 em{font-style:italic;color:var(--terra)}
.lead{font-size:18px;color:var(--ink-2);max-width:620px}
.btn{display:inline-flex;align-items:center;gap:8px;border-radius:999px;padding:14px 24px;font-weight:800;font-size:15px;text-decoration:none;cursor:pointer;border:1.5px solid transparent;font-family:var(--sans)}
.btn.terra{background:var(--terra);color:#fff}.btn.terra:hover{background:var(--terra-d)}
.btn.line{background:transparent;border-color:var(--ink);color:var(--ink)}
.btn.ghost{background:transparent;color:var(--ink-2);border-color:var(--line)}
.hero{padding:34px 0 26px;display:grid;grid-template-columns:1.2fr .8fr;gap:30px;align-items:center}
.hero img{width:100%;border-radius:24px;border:1px solid var(--line);box-shadow:0 20px 50px rgba(31,27,22,.10)}
.levels{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:22px 0 34px}
.levels div{background:#fff;border:1px solid var(--line);border-radius:16px;padding:10px;text-align:center}
.levels img{width:100%;border-radius:12px}.levels b{display:block;font-size:12px;margin-top:6px;line-height:1.2}.levels small{color:var(--mute);font-size:10.5px;font-weight:700;letter-spacing:.08em}
.note{font-size:13.5px;color:var(--mute);background:var(--paper-2);border-radius:14px;padding:12px 16px;margin:18px 0 0}
/* quiz */
#quiz{display:none;padding:30px 0 60px}
.prog{display:flex;align-items:center;gap:14px;font-size:12.5px;font-weight:800;letter-spacing:.1em;color:var(--mute);text-transform:uppercase}
.bar{flex:1;height:6px;background:var(--line);border-radius:99px;overflow:hidden}.bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--terra),var(--must));transition:width .35s}
.card{background:#fff;border:1px solid var(--line);border-radius:26px;padding:34px;margin-top:20px;box-shadow:0 12px 40px rgba(31,27,22,.06)}
.qn{font-family:var(--serif);font-size:60px;line-height:1;color:var(--terra);opacity:.25;font-weight:600}
.card h2{font-family:var(--serif);font-weight:600;font-size:clamp(22px,3.4vw,30px);line-height:1.15;letter-spacing:-.01em;margin:6px 0 22px}
.opts{display:grid;gap:10px}
.opt{display:flex;gap:14px;align-items:center;border:1.5px solid var(--line);border-radius:16px;padding:14px 16px;cursor:pointer;background:var(--paper);font-size:15.5px;transition:.15s}
.opt:hover{border-color:var(--terra);transform:translateX(3px)}.opt.sel{border-color:var(--terra);background:#FCEBE3}
.opt .k{width:30px;height:30px;border-radius:50%;border:1.5px solid var(--ink);display:grid;place-items:center;font-weight:800;font-size:12px;flex:none}
.opt.sel .k{background:var(--terra);border-color:var(--terra);color:#fff}
.navq{display:flex;justify-content:space-between;margin-top:22px}
/* result */
#res{display:none;padding:26px 0 70px}
.badge{display:grid;grid-template-columns:300px 1fr;gap:34px;align-items:center;background:#fff;border:1px solid var(--line);border-radius:30px;padding:34px;box-shadow:0 20px 60px rgba(31,27,22,.08)}
.badge img{width:100%;border-radius:22px}
.tag{display:inline-block;background:var(--ink);color:var(--must);font-size:11px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;padding:6px 12px;border-radius:999px}
.badge h2{font-family:var(--serif);font-size:clamp(34px,5vw,50px);line-height:1;letter-spacing:-.02em;font-weight:600;margin:12px 0 8px}
.claim{font-family:var(--serif);font-style:italic;font-size:22px;color:var(--terra);margin:0 0 14px;line-height:1.25}
.body{color:var(--ink-2);font-size:16px}
.score{font-size:12.5px;color:var(--mute);font-weight:700;letter-spacing:.08em;text-transform:uppercase;margin-top:12px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:22px}
.box{background:#fff;border:1px solid var(--line);border-radius:22px;padding:24px}
.box h3{font-family:var(--serif);font-weight:600;font-size:21px;margin:0 0 10px}
.box.dark{background:var(--ink);color:var(--paper)}.box.dark h3{color:var(--must)}
.map{display:grid;gap:10px}
.map .row{display:grid;grid-template-columns:26px 1fr 60px;gap:10px;align-items:center;font-size:14px}
.map .num{font-family:var(--serif);font-weight:600;color:var(--terra)}
.map .track{height:9px;background:var(--line);border-radius:99px;overflow:hidden;grid-column:2/4}
.map .track i{display:block;height:100%;background:var(--sage);border-radius:99px}
.map .row.weak .track i{background:var(--terra)}
.map .lab{display:flex;justify-content:space-between;grid-column:2/4;font-size:13.5px}.map .lab small{color:var(--mute);font-weight:700}
.win{list-style:none;padding:0;margin:0;display:grid;gap:10px}.win li{display:flex;gap:10px;font-size:14.5px}.win li::before{content:"✓";color:var(--sage);font-weight:900;flex:none}
.box.dark .win li::before{color:var(--must)}
.start{display:flex;gap:14px;align-items:center;background:#FCEBE3;border:1px solid #F3C9B7;border-radius:18px;padding:16px 18px;margin-top:18px}
.start .ico{width:44px;height:44px;border-radius:12px;background:var(--terra);display:grid;place-items:center;color:#fff;font-family:var(--serif);font-size:22px;flex:none}
.start b{display:block;font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:var(--terra)}
.acts{display:flex;flex-wrap:wrap;gap:10px;margin-top:24px}
.share{margin-top:22px;font-size:14px;color:var(--ink-2);background:var(--paper-2);border-radius:16px;padding:16px 18px}
.share b{color:var(--ink)}
.foot{border-top:1px solid var(--line);padding:22px 0 40px;font-size:13px;color:var(--mute);display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px}
.foot a{color:var(--ink-2)}
@media (max-width:760px){.hero{grid-template-columns:1fr}.levels{grid-template-columns:repeat(3,1fr)}.badge{grid-template-columns:1fr}.badge img{max-width:260px;margin:0 auto}.grid2{grid-template-columns:1fr}.card{padding:22px}}
@media print{
  @page{size:A4 portrait;margin:0}
  body{background:#fff}body::before{display:none}
  .noprint,.top,#intro,#quiz{display:none!important}
  #res{display:block!important;padding:14mm 12mm}
  .wrap{max-width:none;padding:0}
  .badge{box-shadow:none;padding:20px;grid-template-columns:200px 1fr;gap:20px;page-break-inside:avoid}
  .badge h2{font-size:34px}.claim{font-size:18px}.body{font-size:13px}
  .grid2{margin-top:14px;gap:12px}.box{padding:16px;page-break-inside:avoid}.box h3{font-size:17px}
  .win li{font-size:12.5px}.map .row{font-size:12px}.map .lab{font-size:12px}
  .box.dark{background:var(--ink)!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .start{margin-top:12px}.printfoot{display:block!important}
}
.printfoot{display:none;margin-top:18px;font-size:11.5px;color:var(--mute);border-top:1px solid var(--line);padding-top:10px}
</style></head><body>
<div class="wrap">
<div class="top noprint">
  <a class="brand" href="index.html"><svg width="36" height="36" viewBox="0 0 48 48"><rect width="48" height="48" rx="14" fill="#1F1B16"/><circle cx="18" cy="24" r="7" fill="#D9542B"/><circle cx="32" cy="16" r="4" fill="#F2B84B"/><circle cx="32" cy="32" r="4" fill="#5B8A72"/><path d="M24 21l5-4M24 27l5 4" stroke="#FAF5EC" stroke-width="2"/></svg><b>IA aplicada a la docència</b></a>
  <a class="back" href="index.html">← Tornar a la formació</a>
</div>

<section id="intro">
  <div class="hero">
    <div>
      <div class="kicker">Test de 3 minuts · 12 preguntes</div>
      <h1>Quin és el meu <em>nivell en IA</em>?</h1>
      <p class="lead">Dotze preguntes sense trampa. Al final, el teu nivell (de l'1 al 5), la teua insígnia i el bloc de la formació per on hauries de començar. Sense registre, sense correu, sense dades del centre.</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px">
        <button class="btn terra" onclick="startQuiz()">Començar el test →</button>
        <a class="btn ghost" href="index.html#blocs">Veure els 5 blocs</a>
      </div>
    </div>
    <img src="__IMG3__" alt="">
  </div>
  <div class="kicker" style="margin-top:8px">Els 5 nivells</div>
  <div class="levels">__LEVELS__</div>
  <div class="note"><b>Coordines la formació del centre?</b> Fes el test tu i passa l'enllaç al claustre. Cada persona obté el seu nivell en 3 minuts; amb els resultats a la mà sabreu el ritme i els blocs on cal posar més pes. Res s'envia enlloc: tot passa al navegador.</div>
</section>

<section id="quiz">
  <div class="prog"><span id="pnum">1 / 12</span><div class="bar"><i id="pbar"></i></div><span id="plevel"></span></div>
  <div class="card">
    <div class="qn" id="qn">01</div>
    <h2 id="qt"></h2><p style="font-size:12.5px;color:var(--mute);margin:-12px 0 16px">Tria una resposta i confirma amb «Següent».</p>
    <div class="opts" id="opts"></div>
    <div class="navq"><button class="btn ghost" onclick="prev()" id="bprev">← Anterior</button><button class="btn terra" onclick="next()" id="bnext" disabled style="opacity:.5">Següent →</button></div>
  </div>
</section>

<section id="res">
  <div class="kicker">El teu resultat</div>
  <div class="badge" style="margin-top:12px">
    <img id="rimg" src="" alt="">
    <div>
      <span class="tag" id="rtag"></span>
      <h2 id="rname"></h2>
      <p class="claim" id="rclaim"></p>
      <p class="body" id="rbody"></p>
      <div class="score" id="rscore"></div>
    </div>
  </div>
  <div class="start"><div class="ico">→</div><div><b>El teu punt de partida</b><span id="rstart"></span></div></div>
  <div class="grid2">
    <div class="box"><h3>El teu mapa per blocs</h3><p style="font-size:13.5px;color:var(--mute);margin:0 0 12px">Com de sòlid estàs en cada bloc de la formació. En taronja, on més guanyaràs.</p><div class="map" id="rmap"></div></div>
    <div class="box dark"><h3>El curs que et cal</h3><p id="rcurs" style="margin:0 0 12px;font-weight:700"></p><ul class="win" id="rwin"></ul><p style="font-size:12.5px;opacity:.75;margin:14px 0 0">Intel·ligència Artificial aplicada a la docència · 5 blocs · Proposta ideal de 9 h, adaptable en hores i blocs · Agustín Gil Benages</p></div>
  </div>
  <div class="acts noprint">
    <button class="btn terra" onclick="window.print()">Imprimir el meu resultat en PDF</button>
    <button class="btn line" onclick="copyLink()" id="bcopy">Copiar enllaç del test per al claustre</button>
    <button class="btn ghost" onclick="restart()">Repetir el test</button>
  </div>
  <div class="share noprint"><b>Sou un claustre?</b> Si la majoria està en nivell 1-2, el curs va amb ritme de fonaments. Si hi ha mescla, els blocs 2-4 es treballen per parelles de nivells diferents. Si la majoria és 3+, el pes se'n va als agents i fluxos. La proposta ideal són 9 hores, però s'adapta a les hores i als blocs que el centre necessite. I tothom ix amb coses fetes. <a href="index.html#contacte">Parlem-ne →</a></div>
  <div class="printfoot">Test «Quin és el meu nivell en IA?» · Formació «Intel·ligència Artificial aplicada a la docència» · Agustín Gil Benages · <span class="ob" data-u="a.gil2" data-d="edu.gva.es"></span></div>
</section>

<div class="foot noprint"><span>© Agustín Gil Benages · Titular de la web · Contacte: <span class="ob" data-u="a.gil2" data-d="edu.gva.es"></span></span><a href="index.html">Veure la formació completa</a><span style="flex-basis:100%">Sense cookies, sense serveis de tercers, sense registre: les teues respostes es processen només al teu navegador i no s'envien enlloc.</span></div>
</div>
<script>
const Q=__Q__, L=__L__, BL=__BL__, HRS=__HRS__, IMG=__IMGS__;
function shuffle(a){for(let k=a.length-1;k>0;k--){const j=Math.floor(Math.random()*(k+1));[a[k],a[j]]=[a[j],a[k]]}return a}
let i=0, ans=Array(Q.length).fill(null);
function startQuiz(){document.getElementById('intro').style.display='none';document.getElementById('quiz').style.display='block';shuffle(Q);ans=Array(Q.length).fill(null);i=0;render();window.scrollTo(0,0)}
function render(){
  const q=Q[i];document.getElementById('qn').textContent=String(i+1).padStart(2,'0');document.getElementById('qt').textContent=q[0];
  document.getElementById('pnum').textContent=(i+1)+' / '+Q.length;document.getElementById('pbar').style.width=((i)/Q.length*100)+'%';
  document.getElementById('plevel').textContent='Bloc '+q[1]+' · '+BL[q[1]-1];
  const o=document.getElementById('opts');o.innerHTML='';
  q[2].forEach((t,k)=>{const d=document.createElement('div');d.className='opt'+(ans[i]===k?' sel':'');d.innerHTML='<span class="k">'+'ABCD'[k]+'</span><span>'+t+'</span>';d.onclick=()=>{ans[i]=k;render()};o.appendChild(d)});
  document.getElementById('bprev').style.visibility=i?'visible':'hidden';
  const bn=document.getElementById('bnext');bn.disabled=ans[i]===null;bn.style.opacity=ans[i]===null?.5:1;bn.textContent=i===Q.length-1?'Veure el meu nivell →':'Següent →';
}
function prev(){if(i>0){i--;render()}}
function next(){if(ans[i]===null)return;if(i<Q.length-1){i++;render()}else finish()}
function finish(){
  const tot=ans.reduce((a,b)=>a+b,0), max=Q.length*3;
  const lvl=tot<=8?0:tot<=16?1:tot<=24?2:tot<=31?3:4; const l=L[lvl];
  document.getElementById('quiz').style.display='none';document.getElementById('res').style.display='block';window.scrollTo(0,0);
  document.getElementById('rimg').src=IMG[lvl];document.getElementById('rtag').textContent=l.tag;document.getElementById('rname').textContent=l.name;
  document.getElementById('rclaim').textContent=l.claim;document.getElementById('rbody').textContent=l.body;
  document.getElementById('rscore').textContent='Puntuació '+tot+' de '+max+' · Nivell '+(lvl+1)+' de 5';
  document.getElementById('rstart').textContent=l.start;document.getElementById('rcurs').textContent=l.cursname;
  document.getElementById('rwin').innerHTML=l.win.map(w=>'<li>'+w+'</li>').join('');
  const per=[0,0,0,0,0],cnt=[0,0,0,0,0];Q.forEach((q,k)=>{per[q[1]-1]+=ans[k];cnt[q[1]-1]+=3});
  const pct=per.map((p,k)=>Math.round(p/cnt[k]*100));const mn=Math.min(...pct);
  document.getElementById('rmap').innerHTML=pct.map((p,k)=>'<div class="row'+(p===mn||p<40?' weak':'')+'"><span class="num">0'+(k+1)+'</span><div class="lab"><span>'+BL[k]+'</span><small>'+HRS[k]+' · '+p+'%</small></div><div class="track"><i style="width:'+Math.max(6,p)+'%"></i></div></div>').join('');
  document.title='Nivell '+(lvl+1)+' · '+l.name+' · Test IA docents';
}
function restart(){document.getElementById('res').style.display='none';document.getElementById('intro').style.display='block';window.scrollTo(0,0)}
document.querySelectorAll('.ob').forEach(e=>{e.textContent=e.dataset.u+' [arrova] '+e.dataset.d.split('').join('\u200b')});
function copyLink(){const u=location.href.split('#')[0];(navigator.clipboard?navigator.clipboard.writeText(u):Promise.reject()).then(()=>{document.getElementById('bcopy').textContent='Enllaç copiat ✓'}).catch(()=>prompt('Copia este enllaç:',u))}
</script>
</body></html>'''
levels_html=''.join(f'<div><img src="{IMGS[k]}" alt=""><small>NIVELL {k+1}</small><b>{l["name"]}</b></div>' for k,l in enumerate(LEVELS))
html=(html.replace('__IMG3__',IMGS[3]).replace('__LEVELS__',levels_html)
 .replace('__Q__',json.dumps(Q,ensure_ascii=False)).replace('__L__',json.dumps(LEVELS,ensure_ascii=False))
 .replace('__BL__',json.dumps(BLOCS,ensure_ascii=False)).replace('__HRS__',json.dumps(HOURS)).replace('__IMGS__',json.dumps(IMGS)))
open('../questionari.html','w').write(html); print('quiz',len(html)//1024,'KB')
