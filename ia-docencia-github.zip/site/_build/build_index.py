import json,base64,html,os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
B=json.load(open('blocs.json'))
def b64(p): return "data:image/jpeg;base64,"+base64.b64encode(open(p,'rb').read()).decode()
why={1:"Abans de demanar-li res a una IA, cal saber què és, què fa bé i on s'equivoca. I aprendre a demanar-li-ho bé.",
     2:"El bloc que més s'usa dilluns: activitats, materials i adaptacions fetes amb el propi contingut de cada docent.",
     3:"El currículum com a context. Programacions coherents, rúbriques en versions i retroalimentació que decideix el docent.",
     4:"El salt real: de preguntar a delegar. Assistents configurats per a la tasca repetitiva que cadascú trie.",
     5:"Perquè usar la IA bé també és usar-la amb seguretat: dades, eines corporatives, autoria i pensament crític."}
notes={3:"<b>Canvi d'enfocament.</b> Més que intentar «detectar» automàticament si un treball l'ha fet una IA, es treballen evidències del procés: esborranys, fonts, historial de canvis, defensa oral i capacitat de justificar el resultat.",
       4:"<b>Progressiu.</b> Els fluxos més avançats només s'aborden quan el nivell i el ritme del grup ho permeten.",
       5:"<b>Regla d'or.</b> Cap dada personal d'alumnat en eines d'ús comercial; amb alumnat, només aplicacions autoritzades en AppsEdu. La corporativa és Copilot amb el compte @edu.gva.es."}
out=[]
for b in B:
    items=''.join(f"<li>{html.escape(i)}</li>" for i in b['items'])
    note=f'<div class="note">{notes[b["n"]]}</div>' if b['n'] in notes else ''
    out.append(f'''
    <article class="bloc reveal" id="b{b['n']}">
      <aside>
        <div class="big">{b['n']}</div>
        <h3>{html.escape(b['titol'])}</h3>
        <span class="time"><svg><use href="#i-clock"/></svg> {b['hores']}</span>
        <div class="dl noprint">
          <span class="lab">Material d'este bloc</span>
          <div class="row">
            <button class="btn sm" onclick="printBlock('b{b['n']}')"><svg><use href="#i-pdf"/></svg> PDF</button>
            <a class="btn sm" href="descarregues/Bloc_{b['n']}_{b['slug']}.pptx" download><svg><use href="#i-ppt"/></svg> PPT</a>
          </div>
        </div>
      </aside>
      <main>
        <div class="print-head"><b>Intel·ligència Artificial aplicada a la docència</b><span>Bloc {b['n']} de 5 · Agustín Gil Benages · a.gil2 [arrova] edu.gva.es</span></div>
        <span class="eyebrow">Bloc {b['n']} · {html.escape(b['short'])}</span>
        <p class="why">{why[b['n']]}</p>
        <ul>{items}</ul>
        <div class="prac"><span class="tag">Pràctica</span><div><p>{html.escape(b['practica'])}</p><small>Resultat: {html.escape(b['resultat'])}</small></div></div>
        {note}
      </main>
    </article>''')
t=open('index.tpl.html').read().replace('{{BLOCS}}',''.join(out)).replace('{{HERO}}',b64('../img/hero2.jpg')).replace('{{PONENT}}',b64('../img/ponent.jpg'))
open('../index.html','w').write(t); print('index',len(t)//1024,'KB')
