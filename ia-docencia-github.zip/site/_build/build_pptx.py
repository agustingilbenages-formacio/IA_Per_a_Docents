from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
import json,os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

NAVY=RGBColor(0x1F,0x1B,0x16); CORAL=RGBColor(0xD9,0x54,0x2B); CREAM=RGBColor(0xFA,0xF5,0xEC); GREY=RGBColor(0x8A,0x7F,0x73); WHITE=RGBColor(0xFA,0xF5,0xEC); SKY=RGBColor(0xF2,0xB8,0x4B)
CONTACT="Agustín Gil Benages · a.gil2 [arrova] edu.gva.es"

BLOCS=json.load(open('blocs.json'))

def new():
    p=Presentation(); p.slide_width=Inches(13.333); p.slide_height=Inches(7.5); return p
def bg(s,color):
    f=s.background.fill; f.solid(); f.fore_color.rgb=color
def rect(s,x,y,w,h,color,shape=MSO_SHAPE.RECTANGLE):
    r=s.shapes.add_shape(shape,Inches(x),Inches(y),Inches(w),Inches(h)); r.fill.solid(); r.fill.fore_color.rgb=color; r.line.fill.background(); return r
def text(s,x,y,w,h,t,size=18,bold=False,color=NAVY,align=PP_ALIGN.LEFT,font='Calibri'):
    tb=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h)); tf=tb.text_frame; tf.word_wrap=True
    lines=t if isinstance(t,list) else [t]
    for i,l in enumerate(lines):
        para=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        r=para.add_run(); r.text=l; r.font.size=Pt(size); r.font.bold=bold; r.font.color.rgb=color; r.font.name=font; para.alignment=align
        para.space_after=Pt(6)
    return tb
def footer(s,dark=False):
    text(s,0.6,7.0,9,0.4,CONTACT,10,color=(WHITE if dark else GREY))
    text(s,9.5,7.0,3.3,0.4,"IA aplicada a la docència",10,color=(WHITE if dark else GREY),align=PP_ALIGN.RIGHT)

def cover(p,title,sub,kicker):
    s=p.slides.add_slide(p.slide_layouts[6]); bg(s,NAVY)
    rect(s,0,0,0.35,7.5,CORAL)
    text(s,0.9,1.0,11,0.5,kicker,13,True,CORAL)
    text(s,0.9,1.6,11.5,2.6,title,48,True,WHITE)
    text(s,0.9,4.3,11,1,sub,22,False,SKY)
    text(s,0.9,5.8,11,0.5,"Ponent i creador: Agustín Gil Benages",14,True,WHITE)
    text(s,0.9,6.2,11,0.5,"a.gil2 [arrova] edu.gva.es",13,False,WHITE)
    try: s.shapes.add_picture('../img/hero2.jpg',Inches(8.3),Inches(0.9),height=Inches(3.0))
    except: pass
    return s

def bullets_slide(p,title,items,kicker="",practica=None,hours=None):
    s=p.slides.add_slide(p.slide_layouts[6]); bg(s,CREAM)
    rect(s,0,0,13.333,0.12,CORAL)
    if kicker: text(s,0.7,0.45,10,0.4,kicker,12,True,CORAL)
    text(s,0.7,0.8,10.5,1,title,32,True,NAVY)
    if hours:
        r=rect(s,11.0,0.7,1.7,0.7,NAVY,MSO_SHAPE.ROUNDED_RECTANGLE); tf=r.text_frame; tf.text=hours; tf.paragraphs[0].runs[0].font.size=Pt(14); tf.paragraphs[0].runs[0].font.bold=True; tf.paragraphs[0].runs[0].font.color.rgb=WHITE; tf.paragraphs[0].alignment=PP_ALIGN.CENTER
    y=1.9
    tb=s.shapes.add_textbox(Inches(0.7),Inches(y),Inches(7.6 if practica else 11.8),Inches(4.8)); tf=tb.text_frame; tf.word_wrap=True
    for i,it in enumerate(items):
        para=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        r=para.add_run(); r.text="•  "+it; r.font.size=Pt(15); r.font.color.rgb=NAVY; r.font.name='Calibri'; para.space_after=Pt(9)
    if practica:
        rect(s,8.7,1.9,4.0,4.4,NAVY,MSO_SHAPE.ROUNDED_RECTANGLE)
        text(s,9.0,2.1,3.5,0.4,"PRÀCTICA",12,True,CORAL)
        text(s,9.0,2.55,3.5,3.5,practica,15,False,WHITE)
    footer(s); return s

def full():
    p=new()
    cover(p,"Intel·ligència Artificial aplicada a la docència","De la IA generativa als agents i nous fluxos de treball. Formació pràctica, adaptable i orientada a l'ús real de la IA en la tasca docent.","PROPOSTA D'ACCIÓ FORMATIVA · 9 HORES · 5 BLOCS")
    # glance
    s=p.slides.add_slide(p.slide_layouts[6]); bg(s,CREAM); rect(s,0,0,13.333,0.12,CORAL)
    text(s,0.7,0.6,11,0.8,"La formació d'un colp d'ull",32,True,NAVY)
    text(s,0.7,1.3,11.5,0.8,"Proposta ideal de 9 hores, adaptable a les hores i blocs que el centre necessite: una base clara, aplicacions immediates per a l'aula i una introducció realista als agents d'IA, sense perdre de vista la protecció de dades, la supervisió humana i l'adaptació al nivell del claustre.",14,False,GREY)
    x=0.7
    for b in BLOCS:
        rect(s,x,2.5,2.3,3.6,NAVY if b['n']%2 else WHITE,MSO_SHAPE.ROUNDED_RECTANGLE)
        c= WHITE if b['n']%2 else NAVY
        text(s,x+0.2,2.65,2,0.6,f"0{b['n']}",28,True,CORAL)
        text(s,x+0.2,3.35,1.95,1.6,b['short'],15,True,c)
        text(s,x+0.2,5.4,2,0.5,b['hores'],13,False,c)
        x+=2.42
    footer(s)
    bullets_slide(p,"Descripció i enfocament",[
     "La IA ha passat en molt poc de temps de generar text o imatges a analitzar documents, investigar, crear multimèdia i executar processos complexos.",
     "La gran novetat: els agents. Ja no es tracta de preguntar a un xatbot, sinó de configurar assistents especialitzats amb instruccions, documents i una finalitat concreta.",
     "Orientació pràctica: activitats, recursos, adaptació de materials, planificació, programacions, avaluació, investigació, agents i nous fluxos de treball.",
     "Principi de treball: la IA és una ferramenta de suport. El criteri professional, la validació i les decisions pedagògiques continuen sent del docent."],"1 · ENFOCAMENT")
    bullets_slide(p,"Objectius",[
     "Comprendre de manera pràctica què és la IA generativa, les seues possibilitats i les seues limitacions.",
     "Comunicar-se de manera efectiva amb els models mitjançant prompts, context, documents i fonts.",
     "Aplicar la IA a la creació d'activitats, recursos i materials adaptats a diferents nivells i necessitats.",
     "Utilitzar la IA com a assistent en la planificació, la revisió de programacions i la preparació de Situacions d'Aprenentatge.",
     "Crear rúbriques, qüestionaris i bancs de preguntes mantenint sempre la supervisió humana.",
     "Conéixer i experimentar amb assistents i agents d'IA aplicats a tasques docents reals.",
     "Fer un ús crític, segur, transparent i responsable, coneixent les pautes de protecció de dades i les eines corporatives."],"2 · OBJECTIUS")
    for b in BLOCS:
        bullets_slide(p,b['titol'],b['items'],f"BLOC {b['n']} · {b['short'].upper()}",b['practica'],b['hores'])
    bullets_slide(p,"Metodologia i adaptació al claustre",[
     "Caràcter eminentment pràctic: la teoria es limita al necessari per a entendre possibilitats, límits i riscos.",
     "Seqüència habitual: explicació breu › demostració › pràctica › revisió conjunta › aplicació docent.",
     "Es treballa amb situacions reals del professorat: activitats, programacions, materials, rúbriques, adaptacions, assistents i agents.",
     "Valoració inicial del nivell i els interessos del grup. Velocitat, exemples i profunditat s'adapten al ritme del claustre.",
     "Nivell inicial: es reforcen les bases i la pràctica guiada. Nivell avançat: agents, documents, investigació, automatitzacions i fluxos.",
     "Sempre comprensió i aplicabilitat per damunt de la quantitat de ferramentes."],"4 · METODOLOGIA")
    bullets_slide(p,"Avaluació i formació viva",[
     "Avaluació formativa, pràctica i continuada. Sense projecte final obligatori.",
     "Participació activa i realització de les pràctiques. Creació o adaptació de recursos aplicables a l'aula.",
     "Capacitat de revisar críticament els resultats generats. Ús responsable, segur i transparent.",
     "Document viu: eines, exemples i activitats podran actualitzar-se fins al moment de la formació.",
     "Objectiu final: no aprendre una llista tancada de ferramentes, sinó adquirir criteris per a adaptar-se a l'evolució de la IA."],"5 · AVALUACIÓ")
    s=p.slides.add_slide(p.slide_layouts[6]); bg(s,NAVY); rect(s,0,0,0.35,7.5,CORAL)
    text(s,0.9,1.4,11,0.5,"CONTACTE",13,True,CORAL)
    text(s,0.9,2.0,11,1.2,"Parlem del vostre centre",44,True,WHITE)
    text(s,0.9,3.3,11,1,"La proposta s'adapta al nivell, les etapes i els interessos del claustre. Ompliu el qüestionari de diagnòstic o contacteu directament.",18,False,SKY)
    text(s,0.9,4.6,11,0.5,"Agustín Gil Benages",22,True,WHITE)
    text(s,0.9,5.1,11,0.5,"a.gil2 [arrova] edu.gva.es",18,False,WHITE)
    p.save('../descarregues/IA_aplicada_docencia_formacio_completa.pptx')

def per_block():
    for b in BLOCS:
        p=new()
        cover(p,f"Bloc {b['n']}. {b['titol']}",f"{b['hores']} · Intel·ligència Artificial aplicada a la docència",f"BLOC {b['n']} DE 5 · {b['short'].upper()}")
        bullets_slide(p,"Continguts",b['items'],f"BLOC {b['n']} · {b['short'].upper()}",None,b['hores'])
        s=p.slides.add_slide(p.slide_layouts[6]); bg(s,NAVY); rect(s,0,0,0.35,7.5,CORAL)
        text(s,0.9,1.4,11,0.5,"PRÀCTICA DEL BLOC",13,True,CORAL)
        text(s,0.9,2.0,11.5,2.5,b['practica'],32,True,WHITE)
        text(s,0.9,5.0,11,0.6,"Resultat esperat: "+b['resultat'],16,False,SKY)
        footer(s,True)
        p.save(f"../descarregues/Bloc_{b['n']}_{b['slug']}.pptx")
full(); per_block(); print('pptx ok')
